import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

// Auth
import { AuthProvider } from './context/AuthContext';
import { EventProvider } from './context/EventContext';
import PrivateRoute from './components/routing/PrivateRoute';
import VendorRoute from './components/routing/VendorRoute';
import AdminRoute from './components/routing/AdminRoute';

// Layouts
import MainLayout from './components/layouts/MainLayout';
import DashboardLayout from './components/layouts/DashboardLayout';

// Pages - Public
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import LoginPage from './pages/auth/LoginPage';
import RegisterPage from './pages/auth/RegisterPage';
import VendorListingPage from './pages/vendors/VendorListingPage';
import VendorDetailsPage from './pages/vendors/VendorDetailsPage';

// Pages - User Dashboard
import UserDashboardPage from './pages/dashboard/user/UserDashboardPage';
import UserProfilePage from './pages/dashboard/user/UserProfilePage';
import UserEventsPage from './pages/dashboard/user/UserEventsPage';
import CreateEventPage from './pages/dashboard/user/CreateEventPage';
import EventDetailsPage from './pages/dashboard/user/EventDetailsPage';
import UserBookingsPage from './pages/dashboard/user/UserBookingsPage';
import UserPaymentsPage from './pages/dashboard/user/UserPaymentsPage';

// Pages - Vendor Dashboard
import VendorDashboardPage from './pages/dashboard/vendor/VendorDashboardPage';
import VendorProfilePage from './pages/dashboard/vendor/VendorProfilePage';
import VendorServicesPage from './pages/dashboard/vendor/VendorServicesPage';
import VendorBookingsPage from './pages/dashboard/vendor/VendorBookingsPage';
import VendorReviewsPage from './pages/dashboard/vendor/VendorReviewsPage';
import VendorAnalyticsPage from './pages/dashboard/vendor/VendorAnalyticsPage';

// Pages - Admin Dashboard
import AdminDashboardPage from './pages/dashboard/admin/AdminDashboardPage';
import AdminUsersPage from './pages/dashboard/admin/AdminUsersPage';
import AdminVendorsPage from './pages/dashboard/admin/AdminVendorsPage';
import AdminEventsPage from './pages/dashboard/admin/AdminEventsPage';
import AdminPaymentsPage from './pages/dashboard/admin/AdminPaymentsPage';

// Create a client for React Query
const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <EventProvider>
          <Router>
            <ToastContainer position="top-right" autoClose={5000} />
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<MainLayout />}>
                <Route index element={<HomePage />} />
                <Route path="about" element={<AboutPage />} />
                <Route path="login" element={<LoginPage />} />
                <Route path="register" element={<RegisterPage />} />
                <Route path="vendors" element={<VendorListingPage />} />
                <Route path="vendors/:id" element={<VendorDetailsPage />} />
              </Route>

              {/* User Dashboard Routes */}
              <Route path="/dashboard" element={<PrivateRoute><DashboardLayout /></PrivateRoute>}>
                <Route index element={<UserDashboardPage />} />
                <Route path="profile" element={<UserProfilePage />} />
                <Route path="events" element={<UserEventsPage />} />
                <Route path="events/create" element={<CreateEventPage />} />
                <Route path="events/:id" element={<EventDetailsPage />} />
                <Route path="bookings" element={<UserBookingsPage />} />
                <Route path="payments" element={<UserPaymentsPage />} />
              </Route>

              {/* Vendor Dashboard Routes */}
              <Route path="/vendor-dashboard" element={<VendorRoute><DashboardLayout /></VendorRoute>}>
                <Route index element={<VendorDashboardPage />} />
                <Route path="profile" element={<VendorProfilePage />} />
                <Route path="services" element={<VendorServicesPage />} />
                <Route path="bookings" element={<VendorBookingsPage />} />
                <Route path="reviews" element={<VendorReviewsPage />} />
                <Route path="analytics" element={<VendorAnalyticsPage />} />
              </Route>

              {/* Admin Dashboard Routes */}
              <Route path="/admin" element={<AdminRoute><DashboardLayout /></AdminRoute>}>
                <Route index element={<AdminDashboardPage />} />
                <Route path="users" element={<AdminUsersPage />} />
                <Route path="vendors" element={<AdminVendorsPage />} />
                <Route path="events" element={<AdminEventsPage />} />
                <Route path="payments" element={<AdminPaymentsPage />} />
              </Route>
            </Routes>
          </Router>
        </EventProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
