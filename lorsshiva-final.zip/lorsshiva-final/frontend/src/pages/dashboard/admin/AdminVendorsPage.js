import React, { useState } from 'react';
import { format } from 'date-fns';

const AdminVendorsPage = () => {
  // Mock vendors data
  const [vendors, setVendors] = useState([
    {
      id: 1,
      name: 'Elegant Decor',
      owner: 'Mike Johnson',
      email: 'contact@elegantdecor.com',
      phone: '+1 (555) 123-4567',
      category: 'Decoration',
      status: 'approved',
      featured: true,
      rating: 4.8,
      totalServices: 3,
      totalBookings: 24,
      revenue: 28500,
      joinedAt: new Date('2023-01-10'),
      logo: 'https://via.placeholder.com/40'
    },
    {
      id: 2,
      name: 'Divine Catering',
      owner: 'Sarah Williams',
      email: 'info@divinecatering.com',
      phone: '+1 (555) 234-5678',
      category: 'Catering',
      status: 'approved',
      featured: false,
      rating: 4.6,
      totalServices: 5,
      totalBookings: 18,
      revenue: 32000,
      joinedAt: new Date('2023-02-15'),
      logo: 'https://via.placeholder.com/40'
    },
    {
      id: 3,
      name: 'Sound Masters',
      owner: 'David Brown',
      email: 'info@soundmasters.com',
      phone: '+1 (555) 345-6789',
      category: 'Music & Entertainment',
      status: 'approved',
      featured: true,
      rating: 4.9,
      totalServices: 4,
      totalBookings: 30,
      revenue: 24000,
      joinedAt: new Date('2023-01-05'),
      logo: 'https://via.placeholder.com/40'
    },
    {
      id: 4,
      name: 'Perfect Venue',
      owner: 'Emily Davis',
      email: 'contact@perfectvenue.com',
      phone: '+1 (555) 456-7890',
      category: 'Venue',
      status: 'pending',
      featured: false,
      rating: 0,
      totalServices: 2,
      totalBookings: 0,
      revenue: 0,
      joinedAt: new Date('2023-03-20'),
      logo: 'https://via.placeholder.com/40'
    },
    {
      id: 5,
      name: 'Snap Photography',
      owner: 'Alex Wilson',
      email: 'info@snapphotography.com',
      phone: '+1 (555) 567-8901',
      category: 'Photography',
      status: 'rejected',
      featured: false,
      rating: 0,
      totalServices: 0,
      totalBookings: 0,
      revenue: 0,
      joinedAt: new Date('2023-03-15'),
      logo: 'https://via.placeholder.com/40'
    }
  ]);

  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedVendor, setSelectedVendor] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    owner: '',
    email: '',
    phone: '',
    category: 'Decoration',
    status: 'pending',
    featured: false
  });

  // Filter vendors based on status and search term
  const filteredVendors = vendors.filter(vendor => {
    const matchesFilter = filter === 'all' || vendor.status === filter;
    const matchesSearch = 
      vendor.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      vendor.owner.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vendor.email.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const openModal = (vendor = null) => {
    if (vendor) {
      setSelectedVendor(vendor);
      setFormData({
        name: vendor.name,
        owner: vendor.owner,
        email: vendor.email,
        phone: vendor.phone,
        category: vendor.category,
        status: vendor.status,
        featured: vendor.featured
      });
    } else {
      setSelectedVendor(null);
      setFormData({
        name: '',
        owner: '',
        email: '',
        phone: '',
        category: 'Decoration',
        status: 'pending',
        featured: false
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedVendor(null);
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (selectedVendor) {
      // Update existing vendor
      setVendors(prev => 
        prev.map(vendor => 
          vendor.id === selectedVendor.id ? { ...vendor, ...formData } : vendor
        )
      );
    } else {
      // Add new vendor
      const newVendor = {
        id: vendors.length > 0 ? Math.max(...vendors.map(v => v.id)) + 1 : 1,
        ...formData,
        rating: 0,
        totalServices: 0,
        totalBookings: 0,
        revenue: 0,
        joinedAt: new Date(),
        logo: 'https://via.placeholder.com/40'
      };
      setVendors(prev => [...prev, newVendor]);
    }
    
    closeModal();
  };

  const toggleVendorFeatured = (vendorId) => {
    setVendors(prev => 
      prev.map(vendor => 
        vendor.id === vendorId ? { ...vendor, featured: !vendor.featured } : vendor
      )
    );
  };

  const updateVendorStatus = (vendorId, status) => {
    setVendors(prev => 
      prev.map(vendor => 
        vendor.id === vendorId ? { ...vendor, status } : vendor
      )
    );
  };

  // Calculate statistics
  const totalVendors = vendors.length;
  const approvedVendors = vendors.filter(vendor => vendor.status === 'approved').length;
  const pendingVendors = vendors.filter(vendor => vendor.status === 'pending').length;
  const rejectedVendors = vendors.filter(vendor => vendor.status === 'rejected').length;
  const featuredVendors = vendors.filter(vendor => vendor.featured).length;
  const totalRevenue = vendors.reduce((sum, vendor) => sum + vendor.revenue, 0);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Vendor Management</h1>
        <button 
          onClick={() => openModal()}
          className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded inline-flex items-center"
        >
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
          </svg>
          Add New Vendor
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-sm font-medium text-gray-500 mb-1">Total Vendors</h2>
          <p className="text-2xl font-bold text-blue-600">{totalVendors}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-sm font-medium text-gray-500 mb-1">Approved Vendors</h2>
          <p className="text-2xl font-bold text-green-600">{approvedVendors}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-sm font-medium text-gray-500 mb-1">Pending Approval</h2>
          <p className="text-2xl font-bold text-yellow-600">{pendingVendors}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-sm font-medium text-gray-500 mb-1">Total Revenue</h2>
          <p className="text-2xl font-bold text-indigo-600">${totalRevenue.toLocaleString()}</p>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex flex-wrap gap-2">
            <button 
              onClick={() => setFilter('all')}
              className={`px-4 py-2 rounded-md ${filter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              All Vendors
            </button>
            <button 
              onClick={() => setFilter('approved')}
              className={`px-4 py-2 rounded-md ${filter === 'approved' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Approved
            </button>
            <button 
              onClick={() => setFilter('pending')}
              className={`px-4 py-2 rounded-md ${filter === 'pending' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Pending
            </button>
            <button 
              onClick={() => setFilter('rejected')}
              className={`px-4 py-2 rounded-md ${filter === 'rejected' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Rejected
            </button>
          </div>
          <div className="w-full md:w-64">
            <input
              type="text"
              placeholder="Search vendors..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
        </div>
      </div>
      
      {filteredVendors.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <h2 className="text-xl font-semibold mb-2">No vendors found</h2>
          <p className="text-gray-600">Try adjusting your search or filter criteria.</p>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vendor</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rating</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Services</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bookings</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Revenue</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredVendors.map(vendor => (
                  <tr key={vendor.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          <img className="h-10 w-10 rounded-full" src={vendor.logo} alt={vendor.name} />
                        </div>
                        <div className="ml-4">
                          <div className="flex items-center">
                            <div className="text-sm font-medium text-gray-900">{vendor.name}</div>
                            {vendor.featured && (
                              <span className="ml-2 px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800">
                                Featured
                              </span>
                            )}
                          </div>
                          <div className="text-sm text-gray-500">{vendor.owner}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{vendor.category}</div>
                      <div className="text-xs text-gray-500">Joined {format(vendor.joinedAt, 'MMM d, yyyy')}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        vendor.status === 'approved' ? 'bg-green-100 text-green-800' :
                        vendor.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {vendor.status.charAt(0).toUpperCase() + vendor.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {vendor.rating > 0 ? (
                        <div className="flex items-center">
                          <svg className="w-4 h-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                          <span className="ml-1 text-sm text-gray-600">{vendor.rating}</span>
                        </div>
                      ) : (
                        <span className="text-sm text-gray-500">N/A</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {vendor.totalServices}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {vendor.totalBookings}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      ${vendor.revenue.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button 
                        onClick={() => openModal(vendor)}
                        className="text-blue-600 hover:text-blue-900 mr-2"
                      >
                        Edit
                      </button>
                      
                      {vendor.status === 'pending' && (
                        <>
                          <button 
                            onClick={() => updateVendorStatus(vendor.id, 'approved')}
                            className="text-green-600 hover:text-green-900 mr-2"
                          >
                            Approve
                          </button>
                          <button 
                            onClick={() => updateVendorStatus(vendor.id, 'rejected')}
                            className="text-red-600 hover:text-red-900 mr-2"
                          >
                            Reject
                          </button>
                        </>
                      )}
                      
                      <button 
                        onClick={() => toggleVendorFeatured(vendor.id)}
                        className={`${
                          vendor.featured ? 'text-purple-600 hover:text-purple-900' : 'text-gray-600 hover:text-gray-900'
                        }`}
                      >
                        {vendor.featured ? 'Unfeature' : 'Feature'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Vendor Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">
                  {selectedVendor ? 'Edit Vendor' : 'Add New Vendor'}
                </h2>
                <button 
                  onClick={closeModal}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                  </svg>
                </button>
              </div>
              
              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Business Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Owner Name</label>
                  <input
                    type="text"
                    name="owner"
                    value={formData.owner}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                  >
                    <option value="Decoration">Decoration</option>
                    <option value="Catering">Catering</option>
                    <option value="Photography">Photography</option>
                    <option value="Music & Entertainment">Music & Entertainment</option>
                    <option value="Venue">Venue</option>
                    <option value="Transportation">Transportation</option>
                  </select>
                </div>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <select
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                  >
                    <option value="pending">Pending</option>
                    <option value="approved">Approved</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>
                <div className="mb-4 flex items-center">
                  <input
                    type="checkbox"
                    id="featured"
                    name="featured"
                    checked={formData.featured}
                    onChange={handleChange}
                    className="h-4 w-4 text-blue-600 border-gray-300 rounded"
                  />
                  <label htmlFor="featured" className="ml-2 block text-sm text-gray-900">
                    Featured Vendor
                  </label>
                </div>
                
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={closeModal}
                    className="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded"
                  >
                    {selectedVendor ? 'Update Vendor' : 'Add Vendor'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminVendorsPage; 