import React, { useState } from 'react';
import { format } from 'date-fns';

const AdminEventsPage = () => {
  // Mock events data
  const [events, setEvents] = useState([
    {
      id: 1,
      title: 'Corporate Conference',
      organizer: 'John Doe',
      date: new Date('2023-06-15'),
      location: 'Grand Hotel, New York',
      status: 'upcoming',
      attendees: 120,
      budget: 15000,
      vendors: 3,
      createdAt: new Date('2023-03-10'),
      image: 'https://via.placeholder.com/100'
    },
    {
      id: 2,
      title: 'Wedding Anniversary',
      organizer: 'Jane Smith',
      date: new Date('2023-05-20'),
      location: 'Seaside Resort, Miami',
      status: 'upcoming',
      attendees: 80,
      budget: 8000,
      vendors: 4,
      createdAt: new Date('2023-02-15'),
      image: 'https://via.placeholder.com/100'
    },
    {
      id: 3,
      title: 'Product Launch',
      organizer: 'Mike Johnson',
      date: new Date('2023-03-10'),
      location: 'Tech Center, San Francisco',
      status: 'completed',
      attendees: 200,
      budget: 25000,
      vendors: 5,
      createdAt: new Date('2023-01-20'),
      image: 'https://via.placeholder.com/100'
    },
    {
      id: 4,
      title: 'Birthday Party',
      organizer: 'Sarah Williams',
      date: new Date('2023-07-05'),
      location: 'Williams Residence, Chicago',
      status: 'upcoming',
      attendees: 30,
      budget: 2000,
      vendors: 2,
      createdAt: new Date('2023-04-10'),
      image: 'https://via.placeholder.com/100'
    },
    {
      id: 5,
      title: 'Charity Gala',
      organizer: 'David Brown',
      date: new Date('2023-04-15'),
      location: 'City Hall, Boston',
      status: 'cancelled',
      attendees: 150,
      budget: 18000,
      vendors: 0,
      createdAt: new Date('2023-02-05'),
      image: 'https://via.placeholder.com/100'
    }
  ]);

  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);

  // Filter events based on status and search term
  const filteredEvents = events.filter(event => {
    const matchesFilter = filter === 'all' || event.status === filter;
    const matchesSearch = 
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      event.organizer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.location.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const openEventDetails = (event) => {
    setSelectedEvent(event);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedEvent(null);
  };

  const updateEventStatus = (eventId, status) => {
    setEvents(prev => 
      prev.map(event => 
        event.id === eventId ? { ...event, status } : event
      )
    );
  };

  // Calculate statistics
  const totalEvents = events.length;
  const upcomingEvents = events.filter(event => event.status === 'upcoming').length;
  const completedEvents = events.filter(event => event.status === 'completed').length;
  const cancelledEvents = events.filter(event => event.status === 'cancelled').length;
  const totalBudget = events.reduce((sum, event) => sum + event.budget, 0);
  const totalAttendees = events.reduce((sum, event) => sum + event.attendees, 0);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Event Management</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-sm font-medium text-gray-500 mb-1">Total Events</h2>
          <p className="text-2xl font-bold text-blue-600">{totalEvents}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-sm font-medium text-gray-500 mb-1">Upcoming Events</h2>
          <p className="text-2xl font-bold text-green-600">{upcomingEvents}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-sm font-medium text-gray-500 mb-1">Total Budget</h2>
          <p className="text-2xl font-bold text-indigo-600">${totalBudget.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-sm font-medium text-gray-500 mb-1">Total Attendees</h2>
          <p className="text-2xl font-bold text-purple-600">{totalAttendees.toLocaleString()}</p>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex flex-wrap gap-2">
            <button 
              onClick={() => setFilter('all')}
              className={`px-4 py-2 rounded-md ${filter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              All Events
            </button>
            <button 
              onClick={() => setFilter('upcoming')}
              className={`px-4 py-2 rounded-md ${filter === 'upcoming' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Upcoming
            </button>
            <button 
              onClick={() => setFilter('completed')}
              className={`px-4 py-2 rounded-md ${filter === 'completed' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Completed
            </button>
            <button 
              onClick={() => setFilter('cancelled')}
              className={`px-4 py-2 rounded-md ${filter === 'cancelled' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Cancelled
            </button>
          </div>
          <div className="w-full md:w-64">
            <input
              type="text"
              placeholder="Search events..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
        </div>
      </div>
      
      {filteredEvents.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <h2 className="text-xl font-semibold mb-2">No events found</h2>
          <p className="text-gray-600">Try adjusting your search or filter criteria.</p>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Event</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Organizer</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Attendees</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Budget</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredEvents.map(event => (
                  <tr key={event.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          <img className="h-10 w-10 rounded-full" src={event.image} alt={event.title} />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{event.title}</div>
                          <div className="text-xs text-gray-500">Created {format(event.createdAt, 'MMM d, yyyy')}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{event.organizer}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{format(event.date, 'MMM d, yyyy')}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{event.location}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        event.status === 'upcoming' ? 'bg-green-100 text-green-800' :
                        event.status === 'completed' ? 'bg-blue-100 text-blue-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {event.attendees}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      ${event.budget.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button 
                        onClick={() => openEventDetails(event)}
                        className="text-blue-600 hover:text-blue-900 mr-2"
                      >
                        View
                      </button>
                      
                      {event.status === 'upcoming' && (
                        <>
                          <button 
                            onClick={() => updateEventStatus(event.id, 'completed')}
                            className="text-green-600 hover:text-green-900 mr-2"
                          >
                            Complete
                          </button>
                          <button 
                            onClick={() => updateEventStatus(event.id, 'cancelled')}
                            className="text-red-600 hover:text-red-900"
                          >
                            Cancel
                          </button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Event Details Modal */}
      {isModalOpen && selectedEvent && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Event Details</h2>
                <button 
                  onClick={closeModal}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                  </svg>
                </button>
              </div>
              
              <div className="mb-6">
                <div className="flex items-center mb-4">
                  <img 
                    src={selectedEvent.image} 
                    alt={selectedEvent.title} 
                    className="w-16 h-16 rounded-full mr-4 object-cover"
                  />
                  <div>
                    <h3 className="text-lg font-semibold">{selectedEvent.title}</h3>
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      selectedEvent.status === 'upcoming' ? 'bg-green-100 text-green-800' :
                      selectedEvent.status === 'completed' ? 'bg-blue-100 text-blue-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {selectedEvent.status.charAt(0).toUpperCase() + selectedEvent.status.slice(1)}
                    </span>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Organizer</h4>
                    <p className="text-gray-900">{selectedEvent.organizer}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Date</h4>
                    <p className="text-gray-900">{format(selectedEvent.date, 'MMMM d, yyyy')}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Location</h4>
                    <p className="text-gray-900">{selectedEvent.location}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Created</h4>
                    <p className="text-gray-900">{format(selectedEvent.createdAt, 'MMMM d, yyyy')}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Attendees</h4>
                    <p className="text-gray-900">{selectedEvent.attendees}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Budget</h4>
                    <p className="text-gray-900">${selectedEvent.budget.toLocaleString()}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Vendors</h4>
                    <p className="text-gray-900">{selectedEvent.vendors}</p>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-500 mb-2">Event Summary</h4>
                  <p className="text-gray-700">
                    This is a {selectedEvent.title} organized by {selectedEvent.organizer} at {selectedEvent.location}.
                    The event is scheduled for {format(selectedEvent.date, 'MMMM d, yyyy')} with an expected attendance of {selectedEvent.attendees} people.
                    The total budget allocated for this event is ${selectedEvent.budget.toLocaleString()}, and it involves {selectedEvent.vendors} vendors.
                  </p>
                </div>
                
                <div className="border-t pt-4">
                  <h4 className="text-sm font-medium text-gray-500 mb-2">Admin Actions</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedEvent.status === 'upcoming' && (
                      <>
                        <button 
                          onClick={() => {
                            updateEventStatus(selectedEvent.id, 'completed');
                            closeModal();
                          }}
                          className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded"
                        >
                          Mark as Completed
                        </button>
                        <button 
                          onClick={() => {
                            updateEventStatus(selectedEvent.id, 'cancelled');
                            closeModal();
                          }}
                          className="bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded"
                        >
                          Cancel Event
                        </button>
                      </>
                    )}
                    {selectedEvent.status === 'cancelled' && (
                      <button 
                        onClick={() => {
                          updateEventStatus(selectedEvent.id, 'upcoming');
                          closeModal();
                        }}
                        className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded"
                      >
                        Restore Event
                      </button>
                    )}
                    <button 
                      onClick={closeModal}
                      className="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded"
                    >
                      Close
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminEventsPage; 