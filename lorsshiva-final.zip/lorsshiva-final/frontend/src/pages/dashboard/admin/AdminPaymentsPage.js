import React, { useState } from 'react';
import { format } from 'date-fns';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const AdminPaymentsPage = () => {
  // Mock payments data
  const [payments, setPayments] = useState([
    {
      id: 1,
      customerName: 'John Doe',
      vendorName: 'Elegant Decor',
      serviceName: 'Premium Decoration Package',
      eventName: 'Corporate Conference',
      amount: 1200,
      platformFee: 120,
      status: 'completed',
      paymentMethod: 'Credit Card',
      transactionId: 'TXN123456789',
      date: new Date('2023-06-10')
    },
    {
      id: 2,
      customerName: 'Jane Smith',
      vendorName: 'Divine Catering',
      serviceName: 'Buffet Catering Service',
      eventName: 'Wedding Anniversary',
      amount: 2500,
      platformFee: 250,
      status: 'pending',
      paymentMethod: 'Bank Transfer',
      transactionId: 'TXN987654321',
      date: new Date('2023-05-15')
    },
    {
      id: 3,
      customerName: 'Mike Johnson',
      vendorName: 'Sound Masters',
      serviceName: 'DJ and Sound System',
      eventName: 'Birthday Party',
      amount: 800,
      platformFee: 80,
      status: 'completed',
      paymentMethod: 'PayPal',
      transactionId: 'TXN456789123',
      date: new Date('2023-07-05')
    },
    {
      id: 4,
      customerName: 'Sarah Williams',
      vendorName: 'Perfect Venue',
      serviceName: 'Beachfront Venue',
      eventName: 'Corporate Retreat',
      amount: 3500,
      platformFee: 350,
      status: 'refunded',
      paymentMethod: 'Credit Card',
      transactionId: 'TXN789123456',
      date: new Date('2023-04-01')
    },
    {
      id: 5,
      customerName: 'David Brown',
      vendorName: 'Snap Photography',
      serviceName: 'Event Photography Package',
      eventName: 'Product Launch',
      amount: 1500,
      platformFee: 150,
      status: 'completed',
      paymentMethod: 'Credit Card',
      transactionId: 'TXN234567891',
      date: new Date('2023-03-20')
    }
  ]);

  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [timeRange, setTimeRange] = useState('month');

  // Filter payments based on status and search term
  const filteredPayments = payments.filter(payment => {
    const matchesFilter = filter === 'all' || payment.status === filter;
    const matchesSearch = 
      payment.customerName.toLowerCase().includes(searchTerm.toLowerCase()) || 
      payment.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.transactionId.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const openPaymentDetails = (payment) => {
    setSelectedPayment(payment);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedPayment(null);
  };

  const updatePaymentStatus = (paymentId, status) => {
    setPayments(prev => 
      prev.map(payment => 
        payment.id === paymentId ? { ...payment, status } : payment
      )
    );
  };

  // Calculate statistics
  const totalPayments = payments.length;
  const completedPayments = payments.filter(payment => payment.status === 'completed').length;
  const pendingPayments = payments.filter(payment => payment.status === 'pending').length;
  const refundedPayments = payments.filter(payment => payment.status === 'refunded').length;
  
  const totalRevenue = payments
    .filter(payment => payment.status === 'completed')
    .reduce((sum, payment) => sum + payment.amount, 0);
  
  const totalPlatformFees = payments
    .filter(payment => payment.status === 'completed')
    .reduce((sum, payment) => sum + payment.platformFee, 0);

  // Mock data for revenue chart
  const revenueData = {
    day: [1200, 800, 1500, 2000, 1700, 1900, 2200],
    week: [8000, 7500, 9000, 8500],
    month: [25000, 30000, 28000, 35000, 32000, 38000],
    year: [300000, 350000, 380000]
  };

  // Labels for time-based charts
  const timeLabels = {
    day: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    week: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
    month: ['January', 'February', 'March', 'April', 'May', 'June'],
    year: ['2021', '2022', '2023']
  };

  // Chart data
  const chartData = {
    labels: timeLabels[timeRange],
    datasets: [
      {
        label: 'Revenue',
        data: revenueData[timeRange],
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.5)',
        tension: 0.3
      }
    ]
  };

  // Chart options
  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Revenue Over Time',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value) {
            return '$' + value.toLocaleString();
          }
        }
      }
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Payment Management</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-sm font-medium text-gray-500 mb-1">Total Revenue</h2>
          <p className="text-2xl font-bold text-blue-600">${totalRevenue.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-sm font-medium text-gray-500 mb-1">Platform Fees</h2>
          <p className="text-2xl font-bold text-green-600">${totalPlatformFees.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-sm font-medium text-gray-500 mb-1">Completed Payments</h2>
          <p className="text-2xl font-bold text-indigo-600">{completedPayments}</p>
        </div>
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-sm font-medium text-gray-500 mb-1">Pending Payments</h2>
          <p className="text-2xl font-bold text-yellow-600">{pendingPayments}</p>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Revenue Overview</h2>
          <div className="flex space-x-2">
            <button 
              onClick={() => setTimeRange('day')}
              className={`px-3 py-1 rounded-md text-sm ${timeRange === 'day' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Day
            </button>
            <button 
              onClick={() => setTimeRange('week')}
              className={`px-3 py-1 rounded-md text-sm ${timeRange === 'week' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Week
            </button>
            <button 
              onClick={() => setTimeRange('month')}
              className={`px-3 py-1 rounded-md text-sm ${timeRange === 'month' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Month
            </button>
            <button 
              onClick={() => setTimeRange('year')}
              className={`px-3 py-1 rounded-md text-sm ${timeRange === 'year' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Year
            </button>
          </div>
        </div>
        <div className="h-64">
          <Line data={chartData} options={chartOptions} />
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex flex-wrap gap-2">
            <button 
              onClick={() => setFilter('all')}
              className={`px-4 py-2 rounded-md ${filter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              All Payments
            </button>
            <button 
              onClick={() => setFilter('completed')}
              className={`px-4 py-2 rounded-md ${filter === 'completed' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Completed
            </button>
            <button 
              onClick={() => setFilter('pending')}
              className={`px-4 py-2 rounded-md ${filter === 'pending' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Pending
            </button>
            <button 
              onClick={() => setFilter('refunded')}
              className={`px-4 py-2 rounded-md ${filter === 'refunded' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}
            >
              Refunded
            </button>
          </div>
          <div className="w-full md:w-64">
            <input
              type="text"
              placeholder="Search payments..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
        </div>
      </div>
      
      {filteredPayments.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <h2 className="text-xl font-semibold mb-2">No payments found</h2>
          <p className="text-gray-600">Try adjusting your search or filter criteria.</p>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Transaction ID</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vendor</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredPayments.map(payment => (
                  <tr key={payment.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{payment.transactionId}</div>
                      <div className="text-xs text-gray-500">{payment.paymentMethod}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{payment.customerName}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{payment.vendorName}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{payment.serviceName}</div>
                      <div className="text-xs text-gray-500">{payment.eventName}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">${payment.amount.toLocaleString()}</div>
                      <div className="text-xs text-gray-500">Fee: ${payment.platformFee.toLocaleString()}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{format(payment.date, 'MMM d, yyyy')}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        payment.status === 'completed' ? 'bg-green-100 text-green-800' :
                        payment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button 
                        onClick={() => openPaymentDetails(payment)}
                        className="text-blue-600 hover:text-blue-900 mr-2"
                      >
                        View
                      </button>
                      
                      {payment.status === 'pending' && (
                        <button 
                          onClick={() => updatePaymentStatus(payment.id, 'completed')}
                          className="text-green-600 hover:text-green-900 mr-2"
                        >
                          Approve
                        </button>
                      )}
                      
                      {payment.status === 'completed' && (
                        <button 
                          onClick={() => updatePaymentStatus(payment.id, 'refunded')}
                          className="text-red-600 hover:text-red-900"
                        >
                          Refund
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Payment Details Modal */}
      {isModalOpen && selectedPayment && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Payment Details</h2>
                <button 
                  onClick={closeModal}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                  </svg>
                </button>
              </div>
              
              <div className="mb-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold">{selectedPayment.transactionId}</h3>
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      selectedPayment.status === 'completed' ? 'bg-green-100 text-green-800' :
                      selectedPayment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {selectedPayment.status.charAt(0).toUpperCase() + selectedPayment.status.slice(1)}
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold">${selectedPayment.amount.toLocaleString()}</div>
                    <div className="text-sm text-gray-500">{format(selectedPayment.date, 'MMMM d, yyyy')}</div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Customer</h4>
                    <p className="text-gray-900">{selectedPayment.customerName}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Vendor</h4>
                    <p className="text-gray-900">{selectedPayment.vendorName}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Service</h4>
                    <p className="text-gray-900">{selectedPayment.serviceName}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Event</h4>
                    <p className="text-gray-900">{selectedPayment.eventName}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Payment Method</h4>
                    <p className="text-gray-900">{selectedPayment.paymentMethod}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-500">Platform Fee</h4>
                    <p className="text-gray-900">${selectedPayment.platformFee.toLocaleString()}</p>
                  </div>
                </div>
                
                <div className="border-t pt-4">
                  <h4 className="text-sm font-medium text-gray-500 mb-2">Payment Breakdown</h4>
                  <div className="flex justify-between py-2 border-b">
                    <span>Subtotal</span>
                    <span>${(selectedPayment.amount - selectedPayment.platformFee).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span>Platform Fee (10%)</span>
                    <span>${selectedPayment.platformFee.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between py-2 font-bold">
                    <span>Total</span>
                    <span>${selectedPayment.amount.toLocaleString()}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end gap-2">
                {selectedPayment.status === 'pending' && (
                  <button 
                    onClick={() => {
                      updatePaymentStatus(selectedPayment.id, 'completed');
                      closeModal();
                    }}
                    className="bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded"
                  >
                    Approve Payment
                  </button>
                )}
                
                {selectedPayment.status === 'completed' && (
                  <button 
                    onClick={() => {
                      updatePaymentStatus(selectedPayment.id, 'refunded');
                      closeModal();
                    }}
                    className="bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded"
                  >
                    Refund Payment
                  </button>
                )}
                
                <button 
                  onClick={closeModal}
                  className="bg-gray-500 hover:bg-gray-600 text-white font-medium py-2 px-4 rounded"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPaymentsPage; 