import React, { useContext, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../../../context/AuthContext';
import { useEvents } from '../../../context/EventContext';
import axios from 'axios';
import { 
  CalendarIcon, 
  CreditCardIcon, 
  UserGroupIcon, 
  BuildingStorefrontIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  SparklesIcon,
  StarIcon
} from '@heroicons/react/24/outline';

const UserDashboardPage = () => {
  const { user } = useContext(AuthContext);
  const { events, loading: eventsLoading, getEvents } = useEvents();
  const [stats, setStats] = useState({
    events: 0,
    bookings: 0,
    payments: 0,
    vendors: 0
  });
  const [upcomingEvents, setUpcomingEvents] = useState([]);
  const [recentBookings, setRecentBookings] = useState([]);
  const [recommendedVendors, setRecommendedVendors] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Fetch events using EventContext
        await getEvents();
        
        // Set mock data immediately without setTimeout
        setStats({
          events: events.length,
          bookings: 5,
          payments: 2,
          vendors: 8
        });
        
        setUpcomingEvents([
          {
            id: 1,
            title: 'Wedding Anniversary',
            date: '2025-06-15',
            location: 'Grand Plaza Hotel, New York',
            status: 'planning'
          },
          {
            id: 2,
            title: 'Corporate Conference',
            date: '2025-07-22',
            location: 'Tech Center, San Francisco',
            status: 'upcoming'
          },
          {
            id: 3,
            title: 'Birthday Party',
            date: '2025-05-10',
            location: 'Sunset Beach Resort, Miami',
            status: 'planning'
          }
        ]);
        
        setRecentBookings([
          {
            id: 1,
            vendorName: 'Elegant Catering',
            service: 'Full Catering Service',
            date: '2025-06-15',
            amount: 2500,
            status: 'confirmed'
          },
          {
            id: 2,
            vendorName: 'Bloom Decorations',
            service: 'Wedding Decoration',
            date: '2025-06-15',
            amount: 1800,
            status: 'pending'
          },
          {
            id: 3,
            vendorName: 'SnapShot Photography',
            service: 'Event Photography',
            date: '2025-07-22',
            amount: 1200,
            status: 'confirmed'
          }
        ]);

        setRecommendedVendors([
          {
            id: 1,
            name: 'Luxe Events & Catering',
            category: 'Catering',
            rating: 4.9,
            reviewCount: 128,
            description: 'Luxury catering service with expertise in international cuisine',
            matchScore: 98,
            image: 'https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80',
            tags: ['Luxury', 'International', 'Custom Menus']
          },
          {
            id: 2,
            name: 'Divine Decor',
            category: 'Decoration',
            rating: 4.8,
            reviewCount: 95,
            description: 'Premium event decoration and styling services',
            matchScore: 95,
            image: 'https://images.unsplash.com/photo-1478146896981-b80fe463b330?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80',
            tags: ['Modern', 'Elegant', 'Customizable']
          },
          {
            id: 3,
            name: 'Capture Moments',
            category: 'Photography',
            rating: 4.9,
            reviewCount: 156,
            description: 'Award-winning photography and videography services',
            matchScore: 92,
            image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80',
            tags: ['Professional', 'Creative', 'Documentary']
          }
        ]);
        
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, [getEvents, events.length]);

  // Format date to readable format
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  // Get status color class
  const getStatusColor = (status) => {
    switch (status) {
      case 'planning':
        return 'bg-blue-100 text-blue-800';
      case 'upcoming':
        return 'bg-yellow-100 text-yellow-800';
      case 'ongoing':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const renderAIRecommendations = () => {
    if (loading) {
      return (
        <div className="py-10 text-center text-sm text-gray-500">
          <div className="flex justify-center">
            <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-primary-600"></div>
          </div>
          <div className="mt-2">Loading recommendations...</div>
        </div>
      );
    }

    if (recommendedVendors.length === 0) {
      return (
        <div className="text-center py-10">
          <BuildingStorefrontIcon className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No recommendations</h3>
          <p className="mt-1 text-sm text-gray-500">Start by creating an event to get personalized vendor recommendations.</p>
          <div className="mt-6">
            <Link
              to="/dashboard/events/create"
              className="inline-flex items-center rounded-md bg-primary-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-primary-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-600"
            >
              Create Event
            </Link>
          </div>
        </div>
      );
    }

    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {recommendedVendors.map((vendor) => (
          <div
            key={vendor.id}
            className="relative flex flex-col overflow-hidden rounded-lg border border-gray-200 bg-white"
          >
            <div className="aspect-w-3 aspect-h-2">
              <img
                src={vendor.image}
                alt={vendor.name}
                className="h-48 w-full object-cover"
              />
            </div>
            <div className="flex flex-1 flex-col p-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900">
                  <Link to={`/vendors/${vendor.id}`} className="hover:underline">
                    {vendor.name}
                  </Link>
                </h3>
                <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                  {vendor.matchScore}% match
                </span>
              </div>
              <p className="mt-1 text-sm text-gray-500">{vendor.category}</p>
              <div className="mt-2 flex items-center">
                <StarIcon className="h-4 w-4 text-yellow-400" />
                <span className="ml-1 text-sm text-gray-500">{vendor.rating} ({vendor.reviewCount} reviews)</span>
              </div>
              <p className="mt-2 text-sm text-gray-500">{vendor.description}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {vendor.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <div className="mt-4">
                <Link
                  to={`/vendors/${vendor.id}`}
                  className="text-sm font-medium text-primary-600 hover:text-primary-500"
                >
                  View Details →
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Welcome back, {user?.name || 'User'}!</h1>
        <p className="mt-1 text-sm text-gray-500">
          Here's what's happening with your events and bookings.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <div className="overflow-hidden rounded-lg bg-white shadow">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <CalendarIcon className="h-6 w-6 text-gray-400" aria-hidden="true" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Total Events</dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900">{stats.events}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link to="/dashboard/events" className="font-medium text-primary-700 hover:text-primary-900">
                View all
              </Link>
            </div>
          </div>
        </div>

        <div className="overflow-hidden rounded-lg bg-white shadow">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <BuildingStorefrontIcon className="h-6 w-6 text-gray-400" aria-hidden="true" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Total Bookings</dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900">{stats.bookings}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link to="/dashboard/bookings" className="font-medium text-primary-700 hover:text-primary-900">
                View all
              </Link>
            </div>
          </div>
        </div>

        <div className="overflow-hidden rounded-lg bg-white shadow">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <CreditCardIcon className="h-6 w-6 text-gray-400" aria-hidden="true" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Total Payments</dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900">${stats.payments * 1000}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link to="/dashboard/payments" className="font-medium text-primary-700 hover:text-primary-900">
                View all
              </Link>
            </div>
          </div>
        </div>

        <div className="overflow-hidden rounded-lg bg-white shadow">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <UserGroupIcon className="h-6 w-6 text-gray-400" aria-hidden="true" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Saved Vendors</dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900">{stats.vendors}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link to="/vendors" className="font-medium text-primary-700 hover:text-primary-900">
                Find vendors
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Upcoming Events */}
      <div className="mt-8">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-medium text-gray-900">Upcoming Events</h2>
          <Link to="/dashboard/events" className="text-sm font-medium text-primary-600 hover:text-primary-500">
            View all
          </Link>
        </div>
        <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
          <table className="min-w-full divide-y divide-gray-300">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                  Event
                </th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Date
                </th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Location
                </th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Status
                </th>
                <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {loading || eventsLoading ? (
                <tr>
                  <td colSpan="5" className="py-10 text-center text-sm text-gray-500">
                    <div className="flex justify-center">
                      <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-primary-600"></div>
                    </div>
                    <div className="mt-2">Loading events...</div>
                  </td>
                </tr>
              ) : events.length === 0 ? (
                <tr>
                  <td colSpan="5" className="py-10 text-center text-sm text-gray-500">
                    No upcoming events found.
                    <div className="mt-2">
                      <Link to="/dashboard/events/create" className="text-primary-600 hover:text-primary-500">
                        Create your first event
                      </Link>
                    </div>
                  </td>
                </tr>
              ) : (
                events.map((event) => (
                  <tr key={event.id}>
                    <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                      {event.title}
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{formatDate(event.date)}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{event.location}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm">
                      <span className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${getStatusColor(event.status)}`}>
                        {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                      </span>
                    </td>
                    <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                      <Link to={`/dashboard/events/${event.id}`} className="text-primary-600 hover:text-primary-900">
                        View<span className="sr-only">, {event.title}</span>
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Bookings */}
      <div className="mt-8">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-medium text-gray-900">Recent Bookings</h2>
          <Link to="/dashboard/bookings" className="text-sm font-medium text-primary-600 hover:text-primary-500">
            View all
          </Link>
        </div>
        <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
          <table className="min-w-full divide-y divide-gray-300">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                  Vendor
                </th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Service
                </th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Date
                </th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Amount
                </th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                  Status
                </th>
                <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 bg-white">
              {loading ? (
                <tr>
                  <td colSpan="6" className="py-10 text-center text-sm text-gray-500">
                    <div className="flex justify-center">
                      <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-primary-600"></div>
                    </div>
                    <div className="mt-2">Loading bookings...</div>
                  </td>
                </tr>
              ) : recentBookings.length === 0 ? (
                <tr>
                  <td colSpan="6" className="py-10 text-center text-sm text-gray-500">
                    No bookings found.
                    <div className="mt-2">
                      <Link to="/vendors" className="text-primary-600 hover:text-primary-500">
                        Find vendors to book
                      </Link>
                    </div>
                  </td>
                </tr>
              ) : (
                recentBookings.map((booking) => (
                  <tr key={booking.id}>
                    <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                      {booking.vendorName}
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{booking.service}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{formatDate(booking.date)}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">${booking.amount}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm">
                      <span className={`inline-flex rounded-full px-2 text-xs font-semibold leading-5 ${getStatusColor(booking.status)}`}>
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </span>
                    </td>
                    <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                      <Link to={`/dashboard/bookings/${booking.id}`} className="text-primary-600 hover:text-primary-900">
                        View<span className="sr-only">, {booking.vendorName}</span>
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mt-8">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Link
            to="/dashboard/events/create"
            className="relative block rounded-lg border border-gray-300 bg-white p-6 text-center hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
          >
            <CalendarIcon className="mx-auto h-8 w-8 text-gray-400" aria-hidden="true" />
            <span className="mt-2 block text-sm font-medium text-gray-900">Create New Event</span>
          </Link>
          <Link
            to="/vendors"
            className="relative block rounded-lg border border-gray-300 bg-white p-6 text-center hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
          >
            <BuildingStorefrontIcon className="mx-auto h-8 w-8 text-gray-400" aria-hidden="true" />
            <span className="mt-2 block text-sm font-medium text-gray-900">Find Vendors</span>
          </Link>
          <Link
            to="/dashboard/payments"
            className="relative block rounded-lg border border-gray-300 bg-white p-6 text-center hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2"
          >
            <CreditCardIcon className="mx-auto h-8 w-8 text-gray-400" aria-hidden="true" />
            <span className="mt-2 block text-sm font-medium text-gray-900">Manage Payments</span>
          </Link>
        </div>
      </div>

      {/* AI Vendor Recommendations */}
      <div className="mt-8">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center">
            <SparklesIcon className="h-5 w-5 text-primary-600 mr-2" />
            <h2 className="text-lg font-medium text-gray-900">AI-Powered Vendor Recommendations</h2>
          </div>
          <Link to="/vendors" className="text-sm font-medium text-primary-600 hover:text-primary-500">
            View all vendors
          </Link>
        </div>
        {renderAIRecommendations()}
      </div>
    </div>
  );
};

export default UserDashboardPage; 