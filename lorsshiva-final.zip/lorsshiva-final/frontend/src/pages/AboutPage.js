import React from 'react';

const AboutPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">About Us</h1>
      <div className="bg-white rounded-lg shadow-md p-6">
        <p className="mb-4">
          Welcome to our event planning platform! We connect event organizers with the best vendors
          to create memorable experiences.
        </p>
        <p className="mb-4">
          Our mission is to simplify the event planning process by providing a centralized platform
          where users can find, compare, and book vendors for any type of event.
        </p>
        <p className="mb-4">
          Whether you're planning a wedding, corporate event, birthday party, or any special occasion,
          our platform helps you find the perfect vendors to make your event a success.
        </p>
        <h2 className="text-2xl font-semibold mt-6 mb-4">Our Team</h2>
        <p>
          Our team consists of experienced professionals from the event planning industry who understand
          the challenges of organizing events and are committed to providing the best solutions.
        </p>
      </div>
    </div>
  );
};

export default AboutPage; 