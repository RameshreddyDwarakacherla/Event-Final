import React, { createContext, useState, useContext } from 'react';
import { toast } from 'react-toastify';
import axios from 'axios';

export const EventContext = createContext();

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export const EventProvider = ({ children }) => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(false);

  // Create event
  const createEvent = async (eventData) => {
    try {
      setLoading(true);
      
      const config = {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      };
      
      const response = await axios.post(`${API_URL}/events`, eventData, config);
      
      setEvents(prevEvents => [...prevEvents, response.data]);
      toast.success('Event created successfully!');
      
      return response.data;
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to create event');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Get all events
  const getEvents = async () => {
    try {
      setLoading(true);
      
      const config = {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      };
      
      const response = await axios.get(`${API_URL}/events`, config);
      setEvents(response.data);
      
      return response.data;
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to fetch events');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Get event by ID
  const getEventById = async (eventId) => {
    try {
      setLoading(true);
      
      const config = {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      };
      
      const response = await axios.get(`${API_URL}/events/${eventId}`, config);
      return response.data;
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to fetch event');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Update event
  const updateEvent = async (eventId, updateData) => {
    try {
      setLoading(true);
      
      const config = {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      };
      
      const response = await axios.put(`${API_URL}/events/${eventId}`, updateData, config);
      
      setEvents(prevEvents => 
        prevEvents.map(event => 
          event._id === eventId ? response.data : event
        )
      );
      
      toast.success('Event updated successfully!');
      return response.data;
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to update event');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Delete event
  const deleteEvent = async (eventId) => {
    try {
      setLoading(true);
      
      const config = {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      };
      
      await axios.delete(`${API_URL}/events/${eventId}`, config);
      
      setEvents(prevEvents => prevEvents.filter(event => event._id !== eventId));
      toast.success('Event deleted successfully!');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to delete event');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return (
    <EventContext.Provider
      value={{
        events,
        loading,
        createEvent,
        getEvents,
        getEventById,
        updateEvent,
        deleteEvent
      }}
    >
      {children}
    </EventContext.Provider>
  );
};

export const useEvents = () => {
  const context = useContext(EventContext);
  if (!context) {
    throw new Error('useEvents must be used within an EventProvider');
  }
  return context;
}; 